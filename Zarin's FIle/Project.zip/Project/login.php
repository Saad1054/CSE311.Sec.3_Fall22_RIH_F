<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="../PROJECT/CSS/reg.css">
    <link rel="stylesheet" href="../PROJECT/CSS/all.min.css">
</head>
<body>
    <div class="form_section">
        <div class="form_box">
            <div class="button_box">
                <div id="btn"></div>
                <button type="button" class="toggle_btn" onclick="Admin()">Admin</button>
                <button type="button" class="toggle_btn" onclick="User()">User</button>
            </div>
            <div class="icons">
                <i class="fa-brands fa-facebook"></i>
                <i class="fa-brands fa-twitter"></i>
                <i class="fa-brands fa-google"></i>
    
            </div>
            <form id="Admin" class="reg" action=""  method="post">
                <label>UserName :</label>
                <br>
                <input type="text" name="username" class="name" placeholder="Enter your userName" required>
                <br><br>
                <label>Password :</label>
                <br>
                <input type="password" name="password" class="password" placeholder="Enter your Password" required>
                <br><br>
                <label>Confirm Password :</label>
                <br>
                <input type="password" name="password" class="password" placeholder="Rewrite your Password" required>
                <br><br>
                <button  class="submit_btn">Submit</button>
            </form>

               <form  id="User" class="reg" action="" method="post">
               <label>UserName :</label>
                <br>
                <input type="text" name="username" class="name" placeholder="Enter your userName" required>
                <br><br>
                    
                    <label>Password :</label>
                    <br>
                    <input type="password" name="password" class="password" placeholder="Enter your Password" required>
                    <br><br>
                    <label>Confirm Password :</label>
                    <br>
                   <input type="password" name="password" class="password" placeholder="Rewrite your Password" required>
                   <br><br>
                    <button  class="submit_btn">Submit</button>
                </form>
        </div>
    </div>

    <script>
        var x = document.getElementById("Admin");
        var y = document.getElementById("User");
        var z = document.getElementById("btn");

        function User(){
            x.style.left = "-450px";
            y.style.left = "50px";
            z.style.left = "110px";

        }
        function Admin(){
            x.style.left = "50px";
            y.style.left = "450px";
            z.style.left = "0px";
        }
    


    </script>
    
    


   
</body>
</html>