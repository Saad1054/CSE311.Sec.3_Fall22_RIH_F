<?php

$dbSERVER = 'localhost';
$dbUSERNAME = 'root';
$dbPASSWORD = '';
$dbNAME = 'lucid_healthcare';
 

$conn= mysqli_connect($dbSERVER,$dbUSERNAME,$dbPASSWORD,$dbNAME);
 

if($conn==false)
{
    dir('Error: Cannot connect');
}
else{
    echo 'connection succesfull';
}

?>